/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cem04b;

/**
 *
 * @author Carlos Mendes
 */
public class CEM04b {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Caneta c1 = new Caneta();
        Caneta c2 = new Caneta();
        
        c1.setModelo("Bic");
        c1.setPonta(1.0f);
        c1.status();
        
        c2.modelo = "Bic";
        c2.status();
        
        
    }
    
}
