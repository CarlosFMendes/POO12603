/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex01;

/**
 *
 * @author Carlos Mendes
 */
public class Detector {
    
    public static void detectarMentira() {
        boolean mentira;
        if (kilos2 > Pescador.capacidade){
        mentira = true;
            System.out.println("É mentira!");
    } else System.out.println("Não é mentira!");
}
}
