/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cem02b;

/**
 *
 * @author Carlos Mendes
 */
public class Caneta {
    String modelo, cor;
    float ponta;
    int carga;
    boolean tampada;
    
    void status (){
        System.out.println("Uma caneta " + this.cor);
        System.out.println("Ela está tampada? " + this.tampada);
    }
    void rabiscar(){
        if (this.tampada == true){
            System.out.println("Não posso");
        } else System.out.println("Rabiscando");
    }
    void tampar(){
        this.tampada = true;
    }
    void destampar(){
        this.tampada = false;
    }
    
}
