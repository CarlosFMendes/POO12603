/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cem07;

/**
 *
 * @author Carlos Mendes
 */
public class CEM07 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Lutador l[] = new Lutador[6];
        
       l[0] = new Lutador ("Carlos", "Brasileiro", 27, 1.82f, 74.5f, 10, 2, 4);
       l[1]= new Lutador ("Alex", "Brasileiro", 50, 1.70f, 74.5f, 10, 1, 5);
       
       Luta fight01 = new Luta();
       fight01.marcarLuta(l[0], l[1]);
       fight01.lutar();
       
       
    }
    
}
