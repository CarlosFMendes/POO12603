/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex01;

import java.util.Scanner;

/**
 *
 * @author Carlos Mendes
 */
public class Ex01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Pescador p1 = new Pescador(50);
        
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Quantos kilos de peixe o pescador pegou? ");
        int kilos = scan.nextInt();
        System.out.print("Quanto kilos de peixe o pescador diz que pegou? ");
        int kilos2 = scan.nextInt();
        Detector.detectarMentira();
        
       
    }
    
}
