/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cem02b;

/**
 *
 * @author Carlos Mendes
 */
public class CEM02b {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Caneta c1 = new Caneta();
        c1.cor = "Azul";
        c1.tampada = true;
        c1.carga = 98;
        c1.status();
        c1.tampar();
        c1.rabiscar();
        
        Caneta c2 = new Caneta();
        c2.cor = "Vermelha";
        c2.tampada = false;
        c2.carga = 76;
        c2.status();
        c2.rabiscar();
    }
    
}
